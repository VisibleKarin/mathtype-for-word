#!/usr/bin/env python3
"""Build the full plugin ZIP and, for a default invocation, the portable skill archive."""

from __future__ import annotations

import hashlib
import sys
import zipfile
from pathlib import Path


# .claude holds local agent settings and worktrees, each a full copy of the repository.
EXCLUDED_DIRS = {".git", ".claude", "__pycache__", ".pytest_cache", "dist", "mathtype-for-word-workspace"}
# Fixed, not the checkout folder name: a worktree or an export folder may be named anything.
ARCHIVE_ROOT = Path("mathtype-for-word")
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


def should_include(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    if any(part in EXCLUDED_DIRS for part in relative.parts) or path.suffix in EXCLUDED_SUFFIXES:
        return False
    return relative.parts[:2] != ("evals", "results")


def package(root: Path, output: Path) -> str:
    root = root.resolve()
    output = output.resolve()
    required = [
        root / ".codex-plugin" / "plugin.json",
        root / ".claude-plugin" / "plugin.json",
        root / ".mcp.json",
        root / ".codex-mcp.json",
        root / "skills" / "mathtype-for-word" / "SKILL.md",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing required plugin files: " + ", ".join(missing))
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(root.rglob("*")):
            if path.is_file() and should_include(path, root) and path.resolve() != output:
                archive.write(path, ARCHIVE_ROOT / path.relative_to(root))
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{digest}  {output.name}\n", encoding="ascii"
    )
    return digest


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    output = (
        Path(sys.argv[2])
        if len(sys.argv) > 2
        else root / "dist" / "mathtype-for-word-plugin.zip"
    )
    digest = package(root, output)
    print(f"Created: {output.resolve()}")
    print(f"SHA256: {digest}")
    if len(sys.argv) <= 2:
        skill_root = root / "skills" / "mathtype-for-word"
        skill_output = root / "dist" / "mathtype-for-word.skill"
        with zipfile.ZipFile(skill_output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(skill_root.rglob("*")):
                if path.is_file() and should_include(path, root):
                    archive.write(path, ARCHIVE_ROOT / path.relative_to(skill_root))
        digest = hashlib.sha256(skill_output.read_bytes()).hexdigest()
        skill_output.with_suffix(skill_output.suffix + ".sha256").write_text(
            f"{digest}  {skill_output.name}\n", encoding="ascii"
        )
        print(f"Created: {skill_output.resolve()}")
        print(f"SHA256: {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
