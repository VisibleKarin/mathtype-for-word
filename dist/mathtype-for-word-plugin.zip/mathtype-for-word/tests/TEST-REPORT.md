# Test report

## README-driven workflow and MCP integration

Date: 2026-11-18. Windows desktop Word 16.0 / MathType 7.8.2.441, installed x86 SDK. The bilingual README and skill were updated from the user's edited README and two supplied Word-layout examples; private examples are not shipped.

`python tests/run-readme-integration.py --output-dir <new folder>` passed using synthetic content and the regular MCP server dispatch/bridge:

- Scanned six real Word OMML equations, selected them by one-based object index and source hash, then marked and converted them without leftover scripts. The source file hash remained unchanged.
- Rendered native chapter/section numbers across four batches: `(1.1.1)`, `(1.1.2)`, `(1.2.1)`, `(2.1.1)`, `(2.1.2)`, `(2.2.1)`. Saved validation found six MathType objects, six numbers and two live references. Standalone field update inferred the native mode and passed.
- The regular renderer also passed chapter-only `(1-1)` through `(2-3)` and section-only `(1.1)`, `(1.2)`, `(2.1)`, `(2.2)`, `(2.3)`, `(3.1)` profiles, each with two native references.
- Automatic Full-size matching read actual 10.5 pt body characters while Normal was 20 pt. Saved Full readback was 10.5 pt, MathML structure/other preferences agreed, and unselected package parts were preserved.
- A follow-up native check with equal amounts of directly formatted 10/12 pt body text failed at `resolve-body-size-3` with an explicit ambiguity error; no output was published and the input hash was unchanged. The context search inspects nearest eligible paragraphs rather than every character in the manuscript.
- A separate local conversion changed only one of six OMML equations, explicitly expected five remaining OMML objects, and passed. All five unselected OMML XML subtrees matched the source exactly.
- Word PDF exports of the chapter/section and section-only outputs were inspected at page size: centered equations, right-tab numbers and prose references were legible without clipping or overlap. New display tab positions were stored in physical units for the actual line width. Poppler emitted the previously observed Symbol/ArialUnicode display-font fallback warnings; inspected symbols remained visible.

The complete non-Office suite passed: **123 tests, 117 passed and 6 environment/opt-in skips**; PowerShell parsing passed. Added unit checks cover native mode/boundary metadata across batch normalization, invalid mode/break/count rejection, contextual-size evidence/readback, and malformed OMML targets.

Scope: TeX for OMML conversion must be reviewed; automatic translation of arbitrary OMML is not provided. Grid/baseline and paragraph-continuation choices are contextual skill guidance, not global style changes. Formula-writing advice and illustrations remain future work. Arbitrary initial chapter/section values and x64 SDK live compatibility remain unverified. These checkout/package changes do not update the installed skill or global MCP configuration.

## First use native formatting preflight

Date: 2026-11-18. Word 16.0 / MathType 7.8.2.441 with installed x86 SDK.

- `probe_mathtype_word(check_native_formatting=true)` passed the ordinary Word checks and the new architecture-matched SDK compilation/load/export/actual-connect checks. The native sub-probe opened no Word document, did not use the clipboard, and reported `legacy_vba_format_attempted: false`.
- A worker pointed at a missing SDK failed at `stage: load-sdk` before Word startup and without attempting legacy VBA formatting.
- The actual formatting path repeated the SDK checks and passed the synthetic six-equation integration: selected Full sizes 10/10.5/11/12 pt read back correctly after saving, other preferences/content remained intact, repeated formatting and local replacement passed.
- Unit coverage checks that the optional probe does not burden ordinary Word-only work, that native initialization failure is visible, and that a failed Word probe does not continue to SDK/legacy formatting.
- The full non-Office suite ran 120 tests: 114 passed, 6 environment/opt-in skips. PowerShell parsing passed; the actual Word integration above ran separately.

The historical `MTFormatEquations.DoFormatEquations -> MathPage.WLL / MTInitAPI` failure was auxiliary to the original standard renderer; its root cause remains unisolated. The fix routes Full-size work to the already verified native SDK from the outset and adds preflight/diagnostics. It does not claim to repair that legacy VBA path or guarantee compatibility with all Office/MathType versions. Changes remain local until explicitly published; installed skills are not replaced by editing this checkout.

## Native MathType numbering chapter and section test

Date: 2026-11-18. Word 16.0 / MathType 7.8.2.441; hidden Office sessions, synthetic content only.

`tests/run-native-numbering-integration.py` invokes the installed MathType insert-number, insert-reference, next-chapter, next-section and update commands. The document-local number preference is written through MathType's helper; the test bypasses the legacy simple-number normalization and does not change global numbering defaults.

- Continuous `(1)`–`(6)`, chapter `(1-1)`–`(1-3)` / `(2-1)`–`(2-3)`, and chapter/section `(1.1.1)`, `(1.1.2)`, `(1.2.1)`, `(2.1.1)`, `(2.1.2)`, `(2.2.1)` all matched after saving and reopening.
- Each of the four outputs has six genuine MathType objects, zero OMath, six `MTPlaceRef` numbers and six `GOTOBUTTON`/`REF` references with live target bookmarks. No ordinary Word list-numbered paragraphs are present.
- Swapping the first two equation paragraphs updates the addition equation's references from `(1.1.1)` to `(1.1.2)` and the fraction's reference from `(1.1.2)` to `(1.1.1)`. Original native data is preserved in the new equation order.
- Native `MTEditEquationSection2` breaks were inserted by MathType. The three numbering modes contain 1, 2 and 4 equation-break fields respectively, while every document retains exactly one Word section.
- Four one-page native Word PDF exports were rasterized with Poppler and inspected: formula previews, right-aligned numbers and Chinese prose references were legible without clipping or overlap. The packaged DOCX renderer was attempted but its LibreOffice backend is unavailable on this host; native Word export supplied the PDF instead.

This earlier test verified the opt-in native route. The generic MCP chapter/section schema is now covered by the README-driven integration above. Explicit arbitrary starting values and interactive More Breaks / Modify Break dialogs are not covered. See the skill's numbering reference for commands and reproducible usage.

## 0.1.0 personal fork

The fork uses its own initial version number, independent of upstream. After the name/version/README-only revision, 19 static/package checks and 8 MCP protocol checks passed again; equation-processing behavior was unchanged.

Date: 2026-11-18. Environment: Windows, Word 16.0, MathType 7.8.2.441, installed x86 MT6.dll, PowerShell 7.6.9.

The new integration (`python tests/run-local-integration.py --work-dir <new absolute folder>`) uses synthetic documents. It creates six native equations, three native numbers and two references, then adds a soft-break explanation/comment anchor to an equation paragraph. No private manuscript or proprietary SDK/template is distributed.

- Four selected equations were set to 10, 10.5, 11 and 12 pt. Saved/reopened internal Full readback matched all four targets. Before/saved MathML trees and every other saved preference agreed. The other two equations' native data remained unchanged.
- Legacy native-field validation passed after formatting: six MathType objects, no OMath, three numbers `[1, 2, 3]`, two live references.
- Repeating the four size operations passed without adding equations, paragraphs, numbers or references. The formatted and repeated single-page PNGs were byte-identical.
- Replacing the first equation with a taller donor fraction passed local-package validation. The original source number/reference fields, soft break, explanation, comments, bookmarks, styles and other package parts remained intact; only selected OLE/preview/geometry/baseline changed.
- Word PDF exports of formatted, repeated and replaced outputs were rendered and visually checked. All were one page; equations, adjacent text and native numbers were legible without clipping or collisions. Poppler reported missing display-font fallback warnings for Symbol/ArialUnicode, but the inspected pages retained the visible equation symbols.
- The dedicated non-Office unit tests cover stale hashes, duplicate targets, shared previews, source/output protection, malformed/cyclic CFB input, namespace differences, incorrect size readback, changed preferences, and duplicate or same-text/different-structure MathML. They use synthetic CFB/OOXML fixtures and pass without Office.

Known boundaries for this earlier integration: x64 SDK routing has not been live tested. General same-identity structural edits, floating equations and PowerPoint internal size are not covered. Reviewed selected OMML conversion and chapter/section insertion are now tested above. Local edits preserve existing fields; they do not regenerate or update them. Legacy render's extra empty-paragraph observation remains a separate issue; local edits do not delete blank paragraphs.

The final non-Office suite (`tests/run-tests.ps1`) ran 118 tests: 112 passed, 6 skipped; PowerShell parsing passed. The skips were one opt-in legacy live-probe test and five installer scenarios needing a conventional, non-Store PowerShell installation. The new Word integration was run separately and passed with actual Word superscript formatting and complete comment anchors; the Word process set returned to its baseline after the normal shutdown grace period. Skill frontmatter validation and reference-link checks passed. Historical upstream results below refer to their original environments.

## 1.4.3

Date: 2026-11-08

Host: Windows 11, Word 16.0, MathType 7.11.1.462, PowerShell 7.6.9, Python 3.13.14. Every render ran through the
bridge in a hidden Word instance of its own while the user had another Word document open; that instance was left
untouched.

### TeX that Toggle TeX does not translate

Probe sets were rendered with `main` 940fc37 (before the change) and inspected through the MTEF data of each saved
object. MathType 7.11.1.462 sets CHAR option bit 0x80 on every character of an untranslated command (drawn red)
and writes U+FFFD for a symbol it cannot map (drawn as a diamond). The first two sets also went through Word's
`ExportAsFixedFormat` PDF, rasterized and read by eye; so did the accent cases of the final set. The final set's
display environments and accents were also drawn from their WMF previews with GDI+, which is what Word shows on
screen. Wherever two methods covered an object, they agreed on red text and diamonds.

| Set | Objects | Red text | Diamond | `validate` on `main` |
|---|---|---|---|---|
| 35 commands from PR #8, display | 35 | `\bm`, `\widetilde`, `\lvert`/`\rvert`, `\mathbfit`, `\widebar`, `\middle` | `\Longrightarrow`, `\iff`, `\lceil`, `\longrightarrow` | `ok: true` |
| Same 35 plus 50 common commands, inline | 85 | the six above plus `\mathtt`, `\pmb`, `\phantom`, `\boxed` | the four above plus `\hookrightarrow` and `\lfloor` in grouped equations | `ok: true` |
| 50 common commands, display | 50 | as inline | as inline | `ok: true` |
| Final set: 61 cases, each in display and inline | 122 | `aligned`, `gathered`, `split`, `\hphantom`, `\phantom`, `\fbox`, `\boxed`, `\coloneqq`, `\mathtt`, `\pmb` and the six above | `\longmapsto`, `\hookrightarrow`, `\lfloor`, `\lceil`, `\mathbb{1}`, `\Longrightarrow`, `\longrightarrow`, `\iff` | `ok: true` |

The final set wrote every multi-row environment with a real `\\` row separator; the earlier sets did not, so
their environment results are superseded. Display and inline gave the same result for every case. Two-row `cases`,
`bmatrix`, `pmatrix`, `vmatrix`, `Vmatrix`, `array` and `\substack` showed neither problem, and the GDI+ drawing
showed their rows. Every replacement in `references/troubleshooting.md` was in the final set and showed neither.
`\operatorname`, `\text`, `\partial`, `\mathop`, `\limits`, `\nolimits` and `\left\|x\right\|` showed neither in
the earlier sets, in both layouts. TeX whose first character is a vertical bar (`|x|`, display and inline,
rendered alone) created no object, and render stopped with `Toggle TeX did not add exactly one MathType object`.

With the change, rendering the final set fails in its first chunk and publishes nothing; the error names every
failing equation, for example `Equation d_one_coloneqq, i_one_coloneqq (a\coloneqq b): MathType kept untranslated
TeX as red text (\coloneqq).` A separate `validate` of the `main` output reports 24 errors, one per failing case, each naming its display and
inline equation.

### Accents on bold symbols

`\tilde{\boldsymbol{M}}`, `\tilde{\mathbf{M}}`, `\hat{\boldsymbol{x}}` and `\hat{\mathbf{x}}` produce MTEF accent
templates (selector 32 for the tilde), and the WMF preview draws the accent from MT Extra; GDI+ shows it. Word's PDF
export left these four accents out. `\boldsymbol{\tilde{M}}`, `\mathbf{\tilde{M}}`, `\boldsymbol{\hat{x}}`,
`\mathbf{\hat{x}}`, `\tilde{M}`, `\bar{\boldsymbol{x}}` and `\vec{\boldsymbol{x}}` kept their accents in the PDF.

Validation matches a saved object to its manifest equation through the TeX MathType stores in it. MathType stores
that TeX trimmed and, for non-ASCII text, in the ANSI code page: `\bm{\text{質量}}` was stored as the cp950 bytes
`BD E8 B6 71` for `質量`, and `  \bm{y}  ` as `\bm{y}`. Before validation decoded and trimmed it, both rendered
red and were published with `ok: true` and only a warning. Now all three red equations of that set (the two
above and `a  +  \bm{z}`) fail validation, and nothing is published. As a second guard, a render whose output
holds more such objects than its input did also fails on the ones it cannot match.

A background job's `get_mathtype_render_status` result now carries the report: after the batched render below
it read `ok: true`, numbers `[1, 2, 3]`, no warnings.

### Rendering into a document that already holds MathType numbers

Input: a rendered document with six MathType objects, one numbered display and one reference, plus new markers.

| Case | `main` 940fc37 | With the change |
|---|---|---|
| One new inline equation, one session | fails: `Expected 0 native number fields; found 1.` | `ok: true`, existing 1 and 1, numbers `[1]` |
| `\alpha_k` inline and two numbered displays plus two references, `--batch-size 2` (3 chunks) | fails in the last chunk the same way | `ok: true`, existing 1 and 1, numbers `[1, 2, 3]`, 3 references |

In both outputs the six existing objects kept byte-identical `Equation Native` streams.

### Timing

Each with `Measure-Command`, twice: a separate `validate` took 6.8 and 6.9 s on the 9-object batched output and
9.1 s twice on the 122-object set; render had already returned the same report. `probe` took 6.0 and 4.8 s.

## 1.4.2

Date: 2026-10-14

Host: Windows 11, Word 16.0, MathType 7.11.1.462, PowerShell 7.6.6, Python 3.13.14, codex-cli 0.162.1 (npm), 0.153.4
and 0.144.1 (bundled with the Codex desktop app), Claude Code 2.1.296

### Validators

| Validator | Result |
|---|---|
| Codex `skill-creator/scripts/quick_validate.py` | PASS |
| Claude official `skill-creator/scripts/quick_validate.py` | PASS |
| `claude plugin validate .` (marketplace manifest) | PASS |
| `claude plugin validate .claude-plugin/plugin.json` | PASS |
| `plugin-scanner scan` 3.43.1 | 94/100 (A), 0 critical, high, medium or low findings; 83/100 on 1.4.1 |

### Office-free suite

`pwsh.exe -NoProfile -ExecutionPolicy Bypass -File tests\run-tests.ps1`: 104 Python tests passed, 1 skipped (live
MCP calls), and every PowerShell file parsed. New coverage: both marketplaces list the repository root under the
plugin's name, and both marketplace names match the `@mathtype-for-word` suffix in the documented commands.

### Marketplace installs

Each run used an isolated `CODEX_HOME` or `CLAUDE_CONFIG_DIR` and installed from the `release/1.4.2` branch on
GitHub; the user's own Codex and Claude Code configuration was not touched. The first install ran before the version
bump, so it installed 1.4.1, and the upgrade commands then moved it to 1.4.2.

- Codex: `codex plugin marketplace add felimet/mathtype-for-word --ref release/1.4.2` and
  `codex plugin add mathtype-for-word@mathtype-for-word` installed the plugin. `codex plugin marketplace upgrade
  mathtype-for-word` and the same `codex plugin add` installed 1.4.2 and removed the 1.4.1 cache. `codex mcp get`
  showed the plugin cache folder as `cwd`, `tool_timeout_sec` 1200 and the forwarded `env_vars`. Through
  `codex app-server`, with no model call, under 0.162.1, 0.153.4 and 0.144.1: server 1.4.2 with 11 tools;
  `probe_mathtype_word` reported `windows: true` and Word ready and left no Word process behind; relative paths
  came back as an `isError` result.
- Claude Code: `claude plugin marketplace add felimet/mathtype-for-word#release/1.4.2` and
  `claude plugin install mathtype-for-word@mathtype-for-word` installed the plugin. `claude plugin marketplace
  update mathtype-for-word` and `claude plugin update mathtype-for-word@mathtype-for-word` moved it to 1.4.2.
  `claude mcp list` reported `plugin:mathtype-for-word:mathtype-for-word` connected, and `claude plugin details`
  listed one skill and one MCP server.

## 1.4.1

Date: 2026-10-14

Host: Windows 11, Word 16.0, MathType 7.11.1.462, PowerShell 7.6.6, Python 3.13.14, codex-cli 0.162.1 (npm) and
0.144.1 (bundled with the Codex desktop app), Claude Code 2.1.296

### Validators

| Validator | Result |
|---|---|
| Codex `skill-creator/scripts/quick_validate.py` | PASS |
| Claude official `skill-creator/scripts/quick_validate.py` | PASS |
| `claude plugin validate .` | PASS |

### Office-free suite

`pwsh.exe -NoProfile -ExecutionPolicy Bypass -File tests\run-tests.ps1`: 103 Python tests passed, 1 skipped (live
MCP calls), and every PowerShell file parsed; it also passes with `TEMP` set to an 8.3 short path. New coverage:
protocol version negotiation, JSON-RPC batches, notifications that get no reply and run nothing, a JSON `null`
message, unreadable messages (nesting 20000 levels deep, a negative or huge `Content-Length`) followed by a ping
that is still answered, `-32602` for an unknown tool, bad arguments as `isError` results, relative paths refused
before any PowerShell install or bridge call, and a server whose start folder can be renamed while it runs. Each
of these tests fails when its fix is reverted.

### Codex

Each run used an isolated `CODEX_HOME` and a scratch marketplace holding the 1.4.1 tree; the user's
`%USERPROFILE%\.codex` was not touched. `codex plugin add` installed the plugin, and `codex mcp get` showed
`python scripts/mcp_server.py`, the plugin cache folder as `cwd`, `tool_timeout_sec` 1200 and the forwarded
`env_vars`. Through `codex app-server`, with no model call, under both 0.162.1 and 0.144.1, started from an
unrelated session folder:

- `mcpServerStatus/list`: server 1.4.1, 11 tools, no error, and no `defaultPrompt` warning;
- `mcpServer/tool/call` of `probe_mathtype_word`: `windows: true`, Word ready, no Word process left behind;
- a relative `document_path`: an `isError` result naming it;
- `MATHTYPE_WORD_POWERSHELL` set in Codex's environment reached the server (its log reported ignoring the
  missing program the variable named).

With 1.4.0 the same setup listed no tools: Python looked for `scripts\mcp_server.py` in the session folder.

## 1.4.0

Date: 2026-10-13

Host: Windows 11, Word 16.0, PowerPoint 16.0, MathType 7.11.1.462, PowerShell 7.6.6, Python 3.13.14

### Validators

| Validator | Result |
|---|---|
| Codex `skill-creator/scripts/quick_validate.py` | PASS |
| Claude official `skill-creator/scripts/quick_validate.py` | PASS |
| Codex `plugin-creator/scripts/validate_plugin.py` | Not re-run: not installed on this host |

Both skill validators ran with `PYTHONUTF8=1` and an ephemeral `uv run --with pyyaml`.

### Office-free suite

`pwsh.exe -NoProfile -ExecutionPolicy Bypass -File tests\run-tests.ps1`: 97 Python tests passed, 1 skipped (live MCP calls), and every PowerShell file parsed. It also passes with `TEMP` set to an 8.3 short path, as on GitHub's Windows runners. The same suite run by Windows PowerShell 5.1 with no PowerShell 7 on PATH skips the tests that need PowerShell 7 and passes the rest without starting an install. The suite covers, without Office:

- the batched job runner against a fake bridge that applies the bridge's validation rules (chunk planning, anchored references, splitting, resume, older job state, timeouts, background start, status cleanup);
- MCP tool listing, refusals during a render job, and bridge switch mapping;
- the bridge watchdog: kill at the deadline, kill-on-close job, cleanup of only logged and windowless Office processes (window stand-ins of class `OpusApp`, `screenClass` and a dialog class);
- the bridge lock and the warning-preference journal on a scratch registry key and mutex (contention, killed runs, empty and unreadable journals);
- manifest normalization through the real bridge, including every chunk the planner produces;
- ASCII JSON through ANSI code pages, mark-file validation, Word Find escaping and exact-text counting, paragraph boundaries, clipboard retry timing;
- PowerShell 7 installation: `scripts\ensure-pwsh.ps1` run by Windows PowerShell 5.1 against a local HTTP server that serves this host's Microsoft-signed PowerShell 7.6.6 as the release archive. Covered: install and reuse, removal of an older own copy, a refused older own copy, SHA-256 mismatch, a pwsh.exe that reports another version, an unsigned pwsh.exe and one signed by another publisher, an unpinned version, killed-install staging, a second installer waiting on the lock, and cleanup once PowerShell 7 comes from elsewhere. In the MCP server: one install per process, the notice in a reply of its own, the installing and failed replies, a PowerShell 6 `pwsh.exe` on PATH, a stale `MATHTYPE_WORD_POWERSHELL`, the job runner's synchronous install, and a `pwsh.exe` that cannot start;
- the packages in `dist\` against the runtime files they ship.

### Live Word integration

`tests\run-live-integration.ps1`: PASS, re-run after the PowerShell 7 installation change.

- Single session: 6 MathType objects, 3 native numbers `(1)`, `(2)`, `(3)`, 2 native references, no clipped object. The exactly spaced paragraph switched to at-least spacing outside the line grid (`w:snapToGrid w:val="0"`), and the exact row of a table with a vertically merged column switched to at-least.
- Batched with `--batch-size 1` into an output path with CJK characters and a space: 8 Word sessions, each reference in its own session reaching its target through the anchor bookmark; the same counts and repairs, both references bound to the right equations, no anchor left in the output, CJK path intact in ASCII JSON.
- Plain-text draft: scan listed the Word superscripts with their offsets (including one at the end of a table cell and a subscript after the table), the typed reference, and the table cell; mark replaced 5 spans, including `a^2 + b^2 = c^2` and the reference number with `Eq.` kept in the prose; the render of the marked copy produced 4 objects, 1 number and 1 reference.
- After every run: no Word process left, no journal left, and the MathType warning preferences back at their pre-run `REG_SZ` values.

### Live PowerPoint

`tests\run-live-powerpoint-integration.ps1`: PASS, twice, once the clipboard was free. The probe reported Word ready; the render placed one centered `Equation.DSMT4` object named `MathType_root_mean_square_error` whose MathML matched the manifest; validation passed; no Word process was left behind, no journal remained, and a Word window the user had open stayed untouched.

Earlier in the release, another program held the Windows clipboard open for a whole session (`OpenClipboard` failed with `ERROR_ACCESS_DENIED`; the last writer was a chat application). Verified live then: the failure path left no Office process and no journal and named the holder; a presentation the user has open is refused; a validation run attached to the user's PowerPoint left it and its presentation open.

### PowerShell 7 installation

Real download through the MCP server: PASS. The server ran with PowerShell 7 hidden from it (no `pwsh.exe` on `PATH`, `ProgramFiles` pointing at an empty folder, `USERPROFILE` at a scratch profile) and was started by the plugin's own launch command. The first `probe_mathtype_word` call downloaded `PowerShell-7.6.6-win-x64.zip` from GitHub, checked it and returned `powershell.status: installed` with the notice, after 16.5 s; the next call ran the probe in the new copy (Word ready). The install folder held only `7.6.6`, with `pwsh.exe` validly signed by Microsoft and reporting 7.6.6; a second server found that copy and ran the probe with no install and no notice.

The pinned SHA-256 values of `PowerShell-7.6.6-win-x64.zip` and `PowerShell-7.6.6-win-arm64.zip` match the asset digests that the GitHub release API reports. A first attempt from a test folder whose `pwsh.exe` path exceeded 260 characters failed, because the ZIP's `pwsh.exe` does not start from such a path; a profile path that long is far outside normal Windows profiles.

## 1.3.0

Date: 2026-07-22

Host: Windows, Word 16.0, PowerPoint 16.0, MathType 7.11.1.462, PowerShell 7.6.3, Python 3.13

### Official validators

| Validator | Result |
|---|---|
| Codex `skill-creator/scripts/quick_validate.py` | PASS |
| Codex `plugin-creator/scripts/validate_plugin.py` | PASS |
| Claude official `skill-creator/scripts/quick_validate.py` | PASS |

The two skill validators were run with `PYTHONUTF8=1` and ephemeral `uv --with pyyaml` because the validator scripts otherwise use Windows CP950 for `Path.read_text()` and import PyYAML. Neither setting is a runtime dependency of this toolkit.

### Automated suite

Command:

```powershell
pwsh.exe -NoProfile -ExecutionPolicy Bypass -File tests\run-tests.ps1 -IncludeLiveOffice -KeepArtifacts
```

Result: PASS

- Python unittest cases: 16 total, all passed with live Office enabled.
- MCP initialize, ping, eight-tool listing, unknown method, shared plugin launcher, and live Word/PowerPoint probe calls: passed.
- Six real bilingual Office eval fixtures are valid ZIP/OOXML packages and contain their declared markers. The two automatic-classification DOCX fixtures contain four neutral equation candidates and three reference candidates each.
- JSON manifests, requested defaults, bilingual academic-writing and symbol-typography contracts, README prerequisites and terminal routing, aligned release versions, platform variables, frontmatter, and placeholder checks: passed.
- All PowerShell files parsed without errors.
- Live Word and silent hidden Word-to-PowerPoint MathType renders plus read-only validation: passed.
- A real MCP `tools/call` render and validate round trip produced an English PPTX with `mathtype_objects=1` and `mathml_verified=1`.

### Live Word integration evidence

Fixture content:

- 1 inline equation.
- 2 numbered display equations, including a fraction and radical.
- 2 references targeting different equations.

Validation result:

```json
{
  "ok": true,
  "counts": {
    "mathtype_objects": 3,
    "word_builtin_omath": 0,
    "native_number_fields": 2,
    "native_reference_fields": 2
  },
  "equation_numbers": [1, 2],
  "errors": [],
  "warnings": []
}
```

Verified mechanisms:

- Numbers: `MACROBUTTON MTPlaceRef` with hidden/current `SEQ MTEqn` fields.
- References: `MTReference` resolved to `GOTOBUTTON` plus nested `REF` and live `ZEqnNum...` bookmarks.
- Number format: `(1)` and `(2)`, with no chapter, section, or separator.
- Placement: `MTDisplayEquation` paragraphs contain center/right tab stops and a right-alignment tab before each number.

### Live PowerPoint integration evidence

The PowerPoint test used `en-presentation-draft.pptx` and its Presentation MathML manifest.

```json
{
  "ok": true,
  "counts": {
    "mathtype_objects": 1,
    "mathml_verified": 1
  },
  "named_objects": ["MathType_root_mean_square_error"],
  "unresolved_markers": [],
  "errors": [],
  "new_word_pids": []
}
```

Verified mechanisms:

- Hidden Word converts one-line TeX through `MTCommand_TeXToggle`; PowerPoint receives the resulting `Equation.DSMT4` OLE object through a windowless presentation.
- The bridge does not call `OLEFormat.Activate`, `AppActivate`, or `SendKeys`, and all Office processes created by the test exited normally.
- Validation reopens the PPTX, reads MathML from the OLE `IDataObject`, rejects Unicode replacement characters, and compares the normalized content signature with the manifest.
- The equation is centered to within one point and the complete marker text box is removed.

### Visual inspection

- The Word DOCX was previously exported through Word to PDF/PNG; centered displays, right-tab numbers, live references, fraction, radical, scripts, and inline placement rendered correctly.
- The Traditional Chinese PPTX was exported at 1600 x 900. `Q = m c_p ΔT` rendered cleanly and centered between its lead-in and `其中，` paragraph with no clipping, overlap, or replacement glyphs.
- Both bilingual DOCX eval outputs were exported to PDF/PNG. The equations were centered, `(1)`/`(2)` were aligned at the right MathType tab, and the Chinese `由式 (1)` / `如式 (2)` plus English `Equation (1)` / `Eq. (2)` references rendered in the surrounding prose.

### Repository evals and independent grading

The repository defines seven evals and uses repository fixtures rather than a hard-coded external path:

- Traditional Chinese DOCX with two numbered equations and two dynamic references.
- English DOCX with two numbered equations, one inline equation, and two dynamic references.
- Traditional Chinese PPTX rendered directly through PowerPoint and MathType.
- English PPTX rendered directly through PowerPoint and MathType.
- Explicit-fallback safety behavior when a prerequisite check fails.
- Traditional Chinese automatic classification without a supplied manifest.
- Academic English automatic classification without a supplied manifest.

The earlier five-eval benchmark was graded once per eval and configuration. The improved skill passed 24 of 24 individual expectations (100%). The frozen old-skill snapshot passed 14 of 24 (58.33%); it matched the Word and safety cases but produced no PPTX for either PowerPoint eval. The official benchmark's equal-per-eval aggregation was 100% versus 60%, a +0.40 delta. Evals 6 and 7 were added afterward and have static fixture/contract coverage but have not yet been executed as live artifact-producing benchmark runs.

Executor timing, token usage, and tool-call counts were not captured during execution. Their machine-readable fields are explicit zero placeholders and are not performance measurements. The static review page plus copied benchmark and grader summaries are preserved under `evals/results/2026-07-20-iteration-2`; all per-run grading, metrics, timing, transcripts, and artifacts remain under `mathtype-for-word-workspace/iteration-2`.

### Operational findings

- PowerShell 7 is required. Windows PowerShell 5.1 blocked on MathType macro calls and its older C# compiler cannot compile the bridge helper.
- PowerPoint conversion now requires hidden Word readiness because MathType 7 rejects direct `IDataObject.SetData` writes for all tested MathML formats. Reusing the proven hidden Word `Toggle TeX` path avoids visible MathType editor automation.
- The bridge briefly uses the Windows clipboard to transfer the converted OLE object, but does not show or activate Word, PowerPoint, or MathType windows and does not synthesize mouse or keyboard input.
- The live test waits up to five seconds for test-created Office processes to exit and fails if Word remains running.
- The bridge preserves the source, saves through a sibling temporary Office file, and refuses to replace an existing output without `-Overwrite`.
