# Changelog

All notable changes to this project are recorded here. The format follows
[Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the project uses
[Semantic Versioning](https://semver.org/). Each release also lists upgrade notes and known limitations.

## [1.5.0] - 2026-11-18

Personal fork release: targeted existing-equation editing, based on upstream 1.4.3.

### Added

- Offline DOCX inventory with source/native fingerprints and relationship-based OLE/preview lookup.
- Internal Full-size formatting for selected main-document inline equations using the installed SDK, an architecture-matched .NET worker, and a private carrier. Saved readback verifies Full and other preferences; MathML tree comparison catches structural changes and accidental appends.
- Package-only replacement from a reviewed donor: copy selected native data, matching preview, geometry and baseline, preserving source paragraphs, native fields, comments, bookmarks, styles and unselected parts. Stale plans, shared parts and unsupported containers are refused; output publishes atomically.
- Three MCP tools and a local CLI, synthetic unit tests and a reproducible opt-in Word integration.

### Changed

- Treat paragraph/definition wording, language, body size and numbering schemes as user/template choices. Keep ordinary Word variables as text when appropriate. Clarify the marker renderer's separate-paragraph/simple-number limitations.
- Route installation and issue links to this fork while retaining upstream authorship/license and history. Rebuild portable packages.

### Validation and limits

- Live tested Word 16.0, MathType 7.8.2.441, x86 SDK: saved 10/10.5/11/12 pt, repeated formatting, six native objects with three native numbers/two references, mixed soft-break/comment paragraph and local replacement. See `tests/TEST-REPORT.md`.
- x64 routing is implemented but not live tested. Floating objects, broad OMML conversion, general same-identity structural editing, alternate numbering insertion and PowerPoint internal-size formatting remain separate work. Existing local numbering is preserved, not rebuilt.

## [1.4.3] - 2026-11-08

Validation catches equations that MathType did not translate, rendering into a document that already holds MathType
numbers works, and the workflow drops a duplicate validation pass.

### Added

- Word validation reads the MTEF data of every saved `Equation.DSMT4` object. Toggle TeX keeps a TeX command it
  cannot translate as red literal text and draws a symbol it cannot map as a diamond (U+FFFD), and before this
  both passed every structural check. An equation of the manifest with either now fails validation with its id,
  its TeX, and the untranslated command (for red text) or the number of diamonds. Objects are matched to the manifest through the TeX MathType stores in them,
  which it trims and keeps in the ANSI code page for non-ASCII text. Other MathType objects only warn, unless a
  render leaves more of them than its input held. Render validates before it publishes, so such an output is no
  longer written. Reported in #8.
- `references/troubleshooting.md` lists the commands that MathType 7.11.1.462 leaves untranslated (`\bm`,
  `\widetilde`, `\lvert`, `\mathbfit`, `\widebar`, `\middle`, `\mathtt`, `\pmb`, `\coloneqq`, `\phantom`,
  `\boxed`, `aligned`, `gathered`, `split`, ...) or draws as a diamond (`\Longrightarrow`, `\iff`, `\lceil`,
  `\lfloor`, `\hookrightarrow`, `\mathbb{1}`, ...), with replacements checked on the same version in display and
  inline equations. TeX that starts with a vertical bar creates no object at all. It also notes that Word's PDF
  export drops an accent written around a bold command (`\tilde{\boldsymbol{M}}`); the skill now puts the accent
  inside (`\boldsymbol{\tilde{M}}`).
- The render result reports `existing_number_fields` and `existing_references`, the counts the input held, and
  `validate_mathtype_word_document` accepts them.

### Fixed

- Adding equations to a document that already held MathType numbered equations or references failed unless
  `partial_manifest` was set: validation expected exactly the manifest's numbers and references and counted the existing ones against it,
  so nothing was published. Validation now expects the existing counts plus the manifest's. A batched render
  takes the counts from its first chunk and passes them to its last chunk. Found while reproducing #10.
- The eval fixtures used `\widetilde`, which renders as red text; they use `\tilde` now.
- `get_mathtype_render_status` of a completed job now includes the validation report (counts, numbers, errors,
  warnings), so a background render's warnings reach the agent.

### Changed

- The skill no longer calls `validate_mathtype_word_document` or `validate_mathtype_powerpoint_presentation`
  after a successful render. Both renders already validate the saved file against the whole manifest before
  they publish it and return that report, so the extra call only started Office again (about 7 s for a
  9-object document, 9 s for 122 objects; `tests/TEST-REPORT.md`). The probe (about 5 s) runs once per task.

### Upgrade notes

- A render job started by an earlier version restarts from the beginning instead of resuming (job state schema 3).

## [1.4.2] - 2026-10-14

Codex and Claude Code install the plugin from this repository's marketplace, and the repository has a security
policy.

### Added

- `.agents/plugins/marketplace.json` (Codex) and `.claude-plugin/marketplace.json` (Claude Code) list the
  repository root as the `mathtype-for-word` plugin. `codex plugin marketplace add felimet/mathtype-for-word` or
  `claude plugin marketplace add felimet/mathtype-for-word` followed by the client's install command installs it,
  and the clients' update commands upgrade it. Before, the skill and the server had to be registered by hand, and
  every upgrade meant doing that again.
- `SECURITY.md` points reporters to GitHub private vulnerability reporting.
- Dependabot proposes updates for the SHA-pinned GitHub Actions every week.

### Removed

- `requirements.txt`, which listed no packages. The server uses only the Python standard library; the READMEs now
  say so.

### Upgrade notes

- Use the plugin or the hand registration, not both. Before installing the plugin, remove a hand-registered
  server (`claude mcp remove mathtype-for-word -s user`, or the `[mcp_servers.mathtype-for-word]` entry in
  `%USERPROFILE%\.codex\config.toml`) and the copied `mathtype-for-word` skill folder. In Codex a registered
  server of the same name takes precedence over the plugin's server; Claude Code would load two servers and two
  skills.
- Claude Code names the plugin's tools `mcp__plugin_mathtype-for-word_mathtype-for-word__*` instead of
  `mcp__mathtype-for-word__*`. Update permission rules or instructions that name the old tools.
- Codex caches an installed plugin by version. To upgrade, run `codex plugin marketplace upgrade
  mathtype-for-word` and then `codex plugin add mathtype-for-word@mathtype-for-word` again.

## [1.4.1] - 2026-10-14

The plugin's MCP server starts under Codex, and the server negotiates the MCP protocol version instead of
echoing whatever the client asks for.

### Fixed

- Codex could not start the plugin's MCP server. Its manifest pointed at `.mcp.json`, whose launcher finds the
  plugin through `CLAUDE_PLUGIN_ROOT`, which Codex neither sets nor forwards, so Python looked for
  `scripts\mcp_server.py` in the folder where the Codex session started. `.codex-mcp.json` used
  `${PLUGIN_ROOT}`, which Codex does not expand. The manifest now points at `.codex-mcp.json`, which runs
  `python scripts/mcp_server.py` with `"cwd": "."`; Codex resolves that against the installed plugin folder.
  Claude Code still uses `.mcp.json` unchanged.
- Under Codex, `probe_mathtype_word` and `probe_mathtype_powerpoint` reported `windows: false` and Office not
  ready, because Codex starts MCP servers without the `OS` environment variable. The bridge now uses `$IsWindows`.
- Codex ends tool calls after 300 s by default, shorter than one Word session of a render can take. The plugin
  sets `tool_timeout_sec` to 1200, above the watchdog of one session at the default `batch_size` (440 s plus 1 s
  per equation already in the document), so in documents of up to about 750 equations a hung session ends with
  the server's own timeout and Office cleanup report. A foreground render runs all its sessions in one tool call
  and can still outlast 1200 s; the skill and the tool description now say to pass `background: true` whenever
  equations plus references exceed `batch_size`.
- Codex forwarded none of the `MATHTYPE_*` settings to the server. The plugin now forwards
  `MATHTYPE_WORD_POWERSHELL`, `MATHTYPE_OFFICE_TIMEOUT_SECONDS`, its 1.3.0 name `MATHTYPE_WORD_TIMEOUT_SECONDS`, and
  `MATHTYPE_BRIDGE_LOCK_WAIT_SECONDS`.
- The server now leaves the folder it was started in. Under Codex that is the plugin's install folder, which
  Windows cannot rename or delete while a process (the server, a bridge or a background render job) works in it.
- Codex dropped the fourth `defaultPrompt` and warned on every load; the manifest now lists three.
- `initialize` echoed any requested protocol version, including ones the server does not implement. It now
  answers with the requested version when it is `2025-11-25`, `2025-06-18`, `2025-03-26` or `2024-11-05`, and
  with `2025-11-25` otherwise, so the client can decide whether to continue.
- A JSON-RPC batch (an array of requests), which `2025-03-26` servers must accept, was answered with an internal
  error. Each request in it is now answered in one array; an empty batch is an invalid request.
- A call to an unknown tool returned internal error `-32603`; it now returns `-32602` (invalid params), as the
  tools specification asks. Bad arguments to `render_mathtype_word_document` and `get_mathtype_render_status`
  also returned `-32603`; they now return a tool result with `isError: true`, which the model can act on.
- A message consisting of JSON `null` stopped the server as if its input had ended. A negative `Content-Length`
  made the server wait for the end of its input.
- A request without an `id` (a notification) for `ping`, `tools/list` or `tools/call` ran and was answered with
  `id: null`. Notifications now get no reply and run nothing.
- `scripts/package_plugin.py` named the archive's top folder after the checkout folder, packaged `.claude` (local
  agent settings and worktrees), and did not require `.codex-mcp.json`.

### Changed

- Every tool refuses a relative path in `input_path`, `document_path`, `presentation_path`, `output_path`,
  `manifest_path`, `validation_manifest_path`, `candidates_path` or `marks_path`, before PowerShell or Office is
  involved. A relative path was resolved against whatever folder the client started the server in (Claude Code:
  usually the project; Codex: the plugin's install folder), and the server now works in the temp folder.

### Upgrade notes

- Agents must pass absolute paths. The skill already tells the agent to resolve relative paths against the
  user's working directory.
- A Codex server registered by hand with `codex mcp add` keeps Codex's 300 s tool limit. Add
  `tool_timeout_sec = 1200` to `[mcp_servers.mathtype-for-word]` in `%USERPROFILE%\.codex\config.toml`, as the
  README shows. Such an entry also takes precedence over the plugin's server of the same name.
- Codex caches an installed plugin by version; reinstall or update the plugin to get 1.4.1.

## [1.4.0] - 2026-10-13

Large Word documents render in resumable batches, optionally as background jobs. New tools turn plain-text
drafts into markers. A timeout no longer ends Word or PowerPoint windows the user opened, PowerPoint work no
longer quits the user's PowerPoint, and a missing PowerShell 7 is installed for the user.

### Added

- Batched rendering. `render_mathtype_word_document` takes `batch_size` (default 40; `0` renders everything in
  one Word session) and `resume` (default true). A manifest with more equations plus references than `batch_size`
  renders in chunks, each in a fresh Word session, so no single session has to survive the few hundred
  conversions after which Word failed with RPC errors `0x800706BA`/`0x800706BE`. A chunk whose Word session
  breaks down is retried split in half; a second timeout in a row stops the job. A reference can target an
  equation numbered in an earlier session of the same job.
- Resume: calling render again with the same input, output and manifest continues after the last checkpoint,
  provided the input DOCX and the manifest are unchanged; a corrected manifest or document starts over. The same
  runner is available without MCP as `python scripts/mathtype_batch.py render` and `status`.
- `background` parameter (default false) on `render_mathtype_word_document`: the job runs detached and the call
  returns at once.
- `get_mathtype_render_status` tool (`output_path`, `cleanup` default false). It reports `queued`, `running`,
  `completed`, `failed`, `interrupted` or `none`, equations and references done and total, chunks, retries, the
  last log lines and the final result. `cleanup: true` deletes the state, log and checkpoints of a finished job.
- `scan_mathtype_candidates` tool (bridge action `scan`). It opens a draft DOCX read-only and writes a candidates
  JSON: every paragraph with plain-text math signals, its Word paragraph number (table cells included), its exact
  text, and the signals with offsets: Greek letters, operators, Unicode and Word sub/superscripts, TeX-like text,
  function calls, typed references such as `Eq. (2)`, `式（2）` or `(2)式`, and Word built-in equations.
- `mark_mathtype_document` tool (bridge action `mark`). It replaces exact text spans in given paragraphs with
  `{{MATH:id}}` or `{{EQREF:id}}` markers and saves a new DOCX. It locates every span before changing anything,
  rejects overlapping spans and spans that cover paragraph marks, note references, objects, breaks, fields or
  Word equations, refuses an `output_path` equal to the source, and saves only when each marker occurs exactly
  once.
- `partial_manifest` parameter (default false) on `render_mathtype_word_document` and
  `validate_mathtype_word_document`: markers outside the manifest become warnings, and number and reference
  counts become lower bounds.
- Optional manifest field `exact_line_spacing` (`"at_least"` by default, or `"keep"`).
- Automatic PowerShell 7 installation. When no PowerShell 7 exists, the first tool call that needs it installs
  PowerShell 7.6.6 (LTS) for the current user from the official ZIP on GitHub, into
  `%USERPROFILE%\.mathtype-for-word\PowerShell\<version>`, in the background. The archive must match the
  SHA-256 pinned in `scripts/ensure-pwsh.ps1`, and `pwsh.exe` must carry a valid Microsoft signature. No administrator rights, prompt, PATH or
  registry change. While it runs, tool calls report it as installing and where; the call after it
  finishes returns only a `notice` telling the user what was installed. Without MCP,
  `powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File scripts/ensure-pwsh.ps1` does the same
  and prints the `pwsh.exe` path to use, and `python scripts/mathtype_batch.py render` installs it when
  needed.

### Changed

- The MCP server no longer needs PowerShell 7 to start. The plugin's launch command runs inline under Windows
  PowerShell 5.1 (`powershell.exe`) rather than as a script file under `pwsh.exe`, so an execution policy that
  allows only signed scripts does not stop it, and the documented manual registrations start
  `python <REPO_ROOT>\scripts\mcp_server.py` directly. The bridge still runs only in PowerShell 7
  and now declares `#Requires -Version 7.0`; a `pwsh.exe` on PATH that is PowerShell 6 is not used.
- Every Word render goes through the job runner, small manifests included. The manifest is checked without
  Office before Word starts (bridge action `check-manifest`). Job state, logs and checkpoints are kept under
  `%APPDATA%\MathTypeForWordAgent\jobs` until a status call with `cleanup: true`.
- Each Word session's watchdog limit grows with its size: 120 s, plus 8 s per equation or reference in the
  session, plus 1 s per equation rendered so far, and never less than `MATHTYPE_OFFICE_TIMEOUT_SECONDS`
  (default 240 s). In 1.3.0 that setting was the limit for the whole render.
- Only one Word render job runs at a time; a second one fails with
  `Another MathType render job is running (pid …, output …)`. While a job is active,
  `render_mathtype_powerpoint_presentation` and `configure_mathtype_word_defaults` are refused. The bridge
  actions `render`, `render-pptx` and `configure-defaults` hold a per-session lock and wait up to 30 s for it
  (`MATHTYPE_BRIDGE_LOCK_WAIT_SECONDS`).
- Word validation warns about MathType objects clipped by exact line spacing or an exact row height, and about
  table rows whose height cannot be inspected. It fails when hidden bookmarks of an unfinished batched render
  remain.
- `scan_mathtype_candidates` and `mark_mathtype_document` are annotated as destructive, because `overwrite` can
  replace an existing file.
- Bridge log lines start with a timestamp.

### Fixed

- On a timeout, the watchdog terminated every Word or PowerPoint process that started during the run,
  including windows the user opened meanwhile. It now ends only processes the bridge logged as its own that
  show no Word or PowerPoint main window or slide show.
- PowerPoint probe, render and validation quit PowerPoint afterwards, closing presentations the user had open.
  The bridge now attaches to a running PowerPoint, refuses a presentation that is already open, closes only its
  own presentation, and quits only an instance it launched.
- Hidden Word could block on MathType's equation-number or reference dialog, because
  `configure_mathtype_word_defaults` and the watchdog wrote the warning preferences as `REG_DWORD`, which
  MathType ignores. They are written as `REG_SZ`. Every render also suppresses the slow field-update dialog
  while it runs.
- The user's MathType warning preferences are journaled before a render changes them. After a timeout or a
  killed run, the MCP server or the next `render`, `render-pptx` or `configure-defaults` call restores them and
  ends hidden Office that the killed run launched, unless it now shows a document window or a slide show.
- Manifests that left out `references`, an equation's `numbered`, or a slide equation's `height_points` failed
  under PowerShell StrictMode. These fields now take their documented defaults.
- A render could hang until the watchdog timeout when a marker sat in a table cell. Markers are now counted in
  the document text and located with one case-sensitive Find.
- An equation taller than its paragraph's exact line spacing, or placed in a table row with an exact height,
  was clipped without a warning. With the default `exact_line_spacing: "at_least"`, such a paragraph switches to
  at-least spacing of the same value outside the line grid, and every exact row that receives an equation
  switches to an at-least row of the same height. The rows are repaired through the cell, so tables with
  vertically merged cells are covered.
- Results containing CJK paths broke callers that decode with an ANSI code page such as cp950. The bridge, the
  job runner and the MCP server now emit ASCII-escaped JSON, and the bridge writes its log as UTF-8.
- PowerPoint rendering failed with Word's misleading "Clipboard is empty" when another program held the
  clipboard open. The transfer is retried twice, 500 ms apart; a persistent failure reports
  `The Windows clipboard is held open by …`, naming the holder, or the last program that wrote to the clipboard
  when the holder cannot be identified.
- The plugin ZIP and the `.skill` package in `dist/` are rebuilt from these sources. The 1.3.0 packages
  predated the last 1.3.0 changes.

### Upgrade notes

- The MCP server lists 11 tools instead of 8: `scan_mathtype_candidates`, `mark_mathtype_document` and
  `get_mathtype_render_status` are new.
- To get automatic PowerShell 7 installation in a manually registered server, register it again with
  `python "<REPO_ROOT>\scripts\mcp_server.py"` as the README shows. A registration that runs
  `pwsh.exe ... scripts\run-mcp.ps1` keeps working wherever PowerShell 7 is installed.
- A failed `render_mathtype_word_document` no longer returns the bridge result unchanged. `error` reads
  `Chunk N failed: …`, the bridge result is under `bridge_result`, and `job`, `resume` and `timeouts` describe how
  to continue. Problems found before Word starts read `<ExceptionType>: <message>`.
- Timeout results report `bridge_office_pids`, `isolated_office_processes_terminated`,
  `office_pids_with_user_windows` and `new_office_pids_left_running`; `isolated_word_pid` and
  `isolated_word_process_terminated` are gone. For Word renders they appear in the result's `timeouts` list.
- Some manifests that 1.3.0 accepted are rejected before Word starts: an equation `id` or a reference `target`
  given as a number instead of a string, and ids that differ only by case. Markers must match the document text
  exactly, including case.
- By default a render now changes exact line spacing that is lower than a new equation, and every exact-height
  table row that receives one. The result lists the equations in `line_spacing_changed_for` and
  `row_height_changed_for`; set `"exact_line_spacing": "keep"` to leave them unchanged.
- PowerPoint rendering replaces what the user had copied to the clipboard, as in 1.3.0. Render and validation
  refuse a presentation that is open in PowerPoint; any open cloud (OneDrive or SharePoint) presentation with
  the same file name counts as open.
- `get_mathtype_render_status` returns `ok: false` for a `failed` or `interrupted` job, which clients show as a
  tool error, and it is annotated as destructive because of `cleanup`.

### Known limitations

- Batched rendering was run live with one operation per session on a small fixture, not on a manuscript with
  hundreds of equations.
- Scan signals are hints; the agent decides each span. `scan_mathtype_candidates` reads only the main text and
  table cells, not notes, headers, footers or text boxes. Paragraphs in `formatted_incomplete` need a look in
  Word before their TeX is written.
- `mark_mathtype_document` cannot create a paragraph break. A span holds at most 255 characters, each `^`
  counted twice.
- A reference in a later batch session cannot target a numbered equation whose paragraph holds another
  numbered equation; the render refuses it.
- In a nested table, only the innermost exact row is repaired.
- There is no tool to cancel a render job; end the process whose `pid` the status reports, and resume later.
- The automatically installed PowerShell 7 is updated only by a new release of this plugin, and application
  control that blocks programs in the user profile (such as AppLocker's default rules) prevents it from running.
  It also cannot start from a user profile whose path is long enough to push `pwsh.exe` past 260 characters.

## [1.3.0] - 2026-07-22

First recorded release: a skill, plugin and local MCP server that place editable MathType equations into Word
DOCX and PowerPoint PPTX, with MathType-native equation numbers and references in Word.

### Added

- Word rendering from a schema v1 JSON manifest: markers such as `{{MATH:id}}` become editable MathType
  `Equation.DSMT4` objects, inline or as centered displays, converted from one-line TeX through MathType's
  Toggle TeX, never Word OMath, images or typed text.
- MathType-native Word equation numbers in the simple form `(1)`, `(2)`, and dynamic references to numbered
  equations; `update_mathtype_word_fields` refreshes them after equations are added, moved or deleted.
- PowerPoint rendering: a marker that is the whole text of a text box becomes a horizontally centered, floating,
  editable `Equation.DSMT4` object named `MathType_<id>`. Each equation needs a one-line `tex`, which creates
  it, and a `mathml` element; validation compares the object's MathML symbol text with it. `height_points`
  sets the height. Word, PowerPoint and MathType stay hidden: hidden Word converts the TeX and the object is
  pasted into a presentation opened without a window.
- A local stdio MCP server using only the Python standard library, with eight tools:
  `probe_mathtype_word`, `probe_mathtype_powerpoint`, `configure_mathtype_word_defaults`,
  `render_mathtype_word_document`, `validate_mathtype_word_document`, `update_mathtype_word_fields`,
  `render_mathtype_powerpoint_presentation` and `validate_mathtype_powerpoint_presentation`. The same actions run
  directly as `scripts/mathtype-word.ps1 -Action <action>`.
- Render, PowerPoint render and field update save to a temporary file, validate it, and publish it only when
  validation passes, returning the report in `validation`. An existing output path is replaced only with
  `overwrite`.
- An MCP watchdog: a job that blocks past the timeout (default 240 s, `MATHTYPE_OFFICE_TIMEOUT_SECONDS`) is
  stopped, the MathType warning preferences are restored, and the run's temporary file is removed.
- During a Word render, MathType's equation-number and reference warning dialogs are turned off and restored
  afterwards. `configure_mathtype_word_defaults` sets the user's defaults on request.
- The `mathtype-for-word` skill: probe, a full-document scan, manifest decisions (inline, display, numbered
  display, reference), render and validate, with references for the schema, native fields, PowerPoint,
  troubleshooting, installation, ribbon operations, and IEEE-style typography for Traditional Chinese and
  English prose. It never falls back to non-MathType output without the user's consent, and it coordinates output
  names with a companion EndNote skill.
- Installation for Codex, Claude Code and Claude Desktop: an install prompt, skill locations, MCP registration
  commands, plugin manifests, `dist/mathtype-for-word-plugin.zip` and `dist/mathtype-for-word.skill` with
  SHA-256 files. `python scripts/package_plugin.py` rebuilds the plugin ZIP.
- `tests/run-tests.ps1` runs the Office-free tests; `-IncludeLiveOffice` adds live Word and PowerPoint runs.

### Upgrade notes

- For installs from the repository before 2026-07-22: every PowerPoint equation needs a one-line `tex`, and a
  render whose output fails validation now writes no output; read `error` and `validation` in the result.

### Known limitations

- Windows only, with desktop Word, PowerPoint and MathType for Windows (tested with 7.11.1.462), Python 3 and
  PowerShell 7. The MathType Add-In for Microsoft 365 is not enough.
- The probe looks for MathType and its Word template only at their default install paths.
- PowerPoint probe, render and validation quit PowerPoint afterwards, closing presentations the user has open.
  PowerPoint rendering replaces the clipboard contents.
- On a timeout, the watchdog ends every Word or PowerPoint process that started during the job, including ones
  the user opened.
- Manifest fields documented as optional (`references`, `numbered`, `height_points`) must still be present.
- Only simple `(n)` numbering; chapter or section numbers are removed.
- Validation checks structure, not appearance; complex equations and slides need a visual check.
- The prebuilt packages in `dist/` predate the last 1.3.0 changes (validation before publishing, temporary file
  cleanup, output naming in the skill). Install from the repository to get them.

[1.4.3]: https://github.com/felimet/mathtype-for-word/releases/tag/v1.4.3
[1.4.2]: https://github.com/felimet/mathtype-for-word/releases/tag/v1.4.2
[1.4.1]: https://github.com/felimet/mathtype-for-word/releases/tag/v1.4.1
[1.4.0]: https://github.com/felimet/mathtype-for-word/releases/tag/v1.4.0
[1.3.0]: https://github.com/felimet/mathtype-for-word/tree/6ab776f
